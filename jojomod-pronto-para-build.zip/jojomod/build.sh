#!/bin/sh
# Requer JDK 17 e Gradle 8.5+. Gera build/libs/jojomod-0.4.0.jar
gradle build && echo "JAR pronto em: build/libs/jojomod-0.4.0.jar"
