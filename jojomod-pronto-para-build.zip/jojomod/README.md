# JoJo Mod (Fabric 1.20.1) v0.4
Compilar: `gradle build` (Gradle 8.5+, JDK 17) -> build/libs/jojomod-0.4.0.jar
Testar: `gradle runClient`

## Como jogar
1. Pegue a Flecha de Stand (aba criativa "JoJo Mod") e clique direito: você ganha um stand aleatório.
   (Para testar: `/stand set star_platinum|the_world|crazy_diamond|gold_experience`, `/stand clear`)
2. Z = invocar/guardar o stand
3. Botão esquerdo (segurar) = stand soca | Botão direito (segurar, mãos vazias) = stand bloqueia
4. R, G, C, V = habilidades de combate 1 a 4 | X = habilidade de utilidade
   (todas as teclas podem ser trocadas em Controles > JoJo Mod)

## Estruturas (v0.4)
- **Mansão do DIO** (`jojomod:dio_mansion`): mansão gótica de 2 andares, 4 torres, pórtico com sacada, biblioteca,
  sala de jantar, troféus, quarto do DIO e o **Salão do Trono** (12x21, teto de 22 blocos) pensado como arena de boss.
- **Igreja do Padre Pucci** (`jojomod:pucci_church`): igreja em cruz com torre sineira (escada de mão até o sino),
  nave com bancos, transepto, vitrais e capela-mor com altar.
- Geram sozinhas no mundo (mansão: planícies/florestas/deserto/savana, rara; igreja: planícies/florestas/taiga/etc.).
- Testar: `/locate structure jojomod:dio_mansion` e `/locate structure jojomod:pucci_church`,
  ou construir direto: `/place structure jojomod:dio_mansion ~ ~ ~`.
- Baús usam as loot tables `jojomod:chests/dio_mansion` e `jojomod:chests/pucci_church` (Flecha de Stand rara).
- **Marcadores de spawn** (para o boss e o Pucci): 1 bloco de `reinforced_deepslate` escondido em cada estrutura
  (trono do DIO / estrado do altar). Veja `ModStructures.java`.
- As construções são geradas por script: edite `tools/structgen/dio_mansion.py` / `pucci_church.py` e rode
  `python3 tools/structgen/generate.py` para regenerar os `.nbt`.
