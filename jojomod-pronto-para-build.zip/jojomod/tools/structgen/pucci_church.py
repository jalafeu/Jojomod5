"""Igreja do Padre Pucci – nave em cruz, torre sineira, capela-mor com altar.

Eixo de simetria: entre x=12 e x=13 (S.mx(x) = 25 - x). Frente = z pequeno.
O chão do terreno fica em y=3 (ar em y=4). Piso da igreja: bloco y=4, pés em y=5.
"""
from builder import B, Structure, AIR

W, H, D = 26, 50, 46


def pane(color):
    return B(f"{color}_stained_glass_pane")


def build():
    S = Structure(W, H, D)
    wall = B("stone_bricks")
    pil = B("polished_diorite")
    dark = B("deepslate_bricks")
    base = B("polished_andesite")
    base2 = B("andesite")
    tiles = B("deepslate_tiles")
    plank = B("spruce_planks")
    quartz = B("smooth_quartz")
    RST, RSL = "deepslate_tile_stairs", "deepslate_tile_slab"
    LOOT = "jojomod:chests/pucci_church"
    lantern = B("lantern", hanging=False, waterlogged=False)
    carpet = B("red_carpet")
    cols = ["blue", "light_blue", "purple", "magenta", "red", "orange", "yellow"]

    def floor(x1, z1, x2, z2, y=4):
        for x in range(x1, x2 + 1):
            for z in range(z1, z2 + 1):
                S.set(x, y, z, base if (x + z) % 2 == 0 else base2)

    def lamp_post(x, z):
        S.set(x, 5, z, pil); S.set(x, 6, z, pil); S.set(x, 7, z, lantern)

    # ------------------------------------------------------------------ limpa + pódio
    S.air(0, 4, 0, 25, H - 1, 45)
    S.fill(0, 0, 1, 25, 3, 45, dark)
    S.fill(0, 4, 1, 25, 4, 45, base)
    S.fill(10, 0, 0, 15, 3, 0, dark)                       # degraus (sobem p/ +z => facing south)
    for x in range(10, 16):
        S.stairs(x, 4, 0, "stone_brick_stairs", "south")
    for (x, z) in ((9, 1), (16, 1)):
        lamp_post(x, z)

    # ------------------------------------------------------------------ NAVE (x 6..19, z 13..36)
    def yc_n(x):                       # altura do teto da nave
        return 16 + min(x - 6, 19 - x)
    S.fill(6, 5, 13, 19, 15, 36, wall)
    for x in range(7, 19):
        S.air(x, 5, 14, x, yc_n(x) - 1, 35)
        S.fill(x, 16, 13, x, yc_n(x) - 1, 13, wall)         # empenas frontal e traseira
        S.fill(x, 16, 36, x, yc_n(x) - 1, 36, wall)
    S.air(9, 5, 36, 16, 15, 36)                              # arco para a capela-mor
    for z in range(12, 37):
        for x in range(6, 13):
            S.stairs(x, 16 + (x - 6), z, RST, "east")
        for x in range(13, 20):
            S.stairs(x, 16 + (19 - x), z, RST, "west")
        S.slab(12, 23, z, RSL); S.slab(13, 23, z, RSL)
    floor(7, 14, 18, 35)
    for z in range(14, 36):
        S.set(12, 5, z, carpet); S.set(13, 5, z, carpet)
    for z in (17, 33):                                       # contrafortes
        S.fill2(5, 5, z, 5, 15, z, pil)
    for z in (15, 19, 31, 35):                               # vitrais da nave
        for i, y in enumerate(range(7, 13)):
            S.set2(6, y, z, pane(cols[(i + z) % len(cols)]))
    for z in (16, 18, 20, 30, 32, 34):                       # bancos (costas voltadas para a entrada)
        for x in (8, 9, 10, 15, 16, 17):
            S.stairs(x, 5, z, "spruce_stairs", "north")
    for z in (16, 24, 33):                                   # lustres (teto em y=22)
        for x in (12, 13):
            S.chandelier(x, z, 22, 4)

    # ------------------------------------------------------------------ TRANSEPTO (braços x 0..5 e 20..25)
    def yc_t(z):
        return 12 + min(z - 20, 29 - z)
    S.fill2(0, 5, 20, 5, 11, 29, wall)
    S.air(6, 5, 21, 6, 13, 28)                               # aberturas para a nave
    S.air(19, 5, 21, 19, 13, 28)
    for z in range(21, 29):
        S.fill2(1, 5, z, 5, yc_t(z) - 1, z, AIR)
        S.fill2(0, 12, z, 0, yc_t(z) - 1, z, wall)           # empena final
    for x in range(0, 6):
        for z in range(19, 31):
            if z <= 24:
                y, f = (12 + (z - 20) if z >= 20 else 11), "south"
            else:
                y, f = (12 + (29 - z) if z <= 29 else 11), "north"
            S.stairs(x, y, z, RST, f)
            S.stairs(S.mx(x), y, z, RST, f)
    floor(1, 21, 5, 28); floor(20, 21, 24, 28)
    floor(6, 21, 6, 28); floor(19, 21, 19, 28)
    # portas duplas + vitral nas paredes finais
    S.air(0, 5, 24, 0, 6, 25)
    S.set(0, 5, 24, B("spruce_door", facing="west", half="lower", hinge="left", open=False, powered=False))
    S.set(0, 6, 24, B("spruce_door", facing="west", half="upper", hinge="left", open=False, powered=False))
    S.set(0, 5, 25, B("spruce_door", facing="west", half="lower", hinge="right", open=False, powered=False))
    S.set(0, 6, 25, B("spruce_door", facing="west", half="upper", hinge="right", open=False, powered=False))
    S.set(25, 5, 24, B("spruce_door", facing="east", half="lower", hinge="right", open=False, powered=False))
    S.set(25, 6, 24, B("spruce_door", facing="east", half="upper", hinge="right", open=False, powered=False))
    S.set(25, 5, 25, B("spruce_door", facing="east", half="lower", hinge="left", open=False, powered=False))
    S.set(25, 6, 25, B("spruce_door", facing="east", half="upper", hinge="left", open=False, powered=False))
    for x in (0, 25):
        for z in (24, 25):
            for i, y in enumerate(range(7, 12)):
                S.set(x, y, z, pane(cols[(i + z) % len(cols)]))
    for (x, z) in ((3, 21), (3, 28)):                        # lanternas internas
        S.set2(x, 5, z, pil); S.set2(x, 6, z, lantern)
    S.chest(1, 5, 22, "east", LOOT)
    S.chest(24, 5, 27, "west", LOOT)

    # ------------------------------------------------------------------ TORRE SINEIRA (x 8..17, z 4..13)
    S.fill(8, 5, 4, 17, 32, 13, wall)
    S.air(9, 5, 5, 16, 10, 12)       # nártex
    S.air(9, 12, 5, 16, 18, 12)      # coro
    S.air(9, 20, 5, 16, 25, 12)      # câmara intermediária
    S.air(9, 27, 5, 16, 32, 12)      # campanário
    for y in (11, 19, 26):
        S.fill(9, y, 5, 16, y, 12, plank)
    for y in (6, 11, 19, 26, 33):                            # faixas de pedra
        for x in range(8, 18):
            for z in range(4, 14):
                if (x in (8, 17) or z in (4, 13)) and S.get(x, y, z) in (wall, plank):
                    S.set(x, y, z, pil if y != 6 else dark)
    floor(9, 5, 16, 12)
    for z in range(5, 13):
        S.set(12, 5, z, carpet); S.set(13, 5, z, carpet)
    for y in range(5, 28):                                   # escada de mão até o campanário
        S.set(9, y, 6, B("ladder", facing="east", waterlogged=False))
    for (x, z) in ((8, 8), (8, 9), (17, 8), (17, 9)):        # vitrais do coro
        for y in range(13, 17):
            S.set(x, y, z, pane("blue" if y % 2 else "light_blue"))
    for x in (12, 13):
        for y in range(13, 17):
            S.set(x, y, 4, pane("red" if y % 2 else "orange"))
    for y in range(27, 32):                                  # arcos abertos do campanário
        for x in (12, 13):
            S.set(x, y, 4, AIR); S.set(x, y, 13, AIR)
        for z in (8, 9):
            S.set(8, y, z, AIR); S.set(17, y, z, AIR)
    S.set(12, 32, 8, pil)                                    # sino
    S.set(12, 31, 8, B("chain", axis="y", waterlogged=False))
    S.set(12, 30, 8, B("bell", facing="north", attachment="ceiling", powered=False))
    for i in range(6):                                       # telhado piramidal
        y = 33 + i
        x1, x2, z1, z2 = 7 + i, 18 - i, 3 + i, 14 - i
        for x in range(x1, x2 + 1):
            for z in range(z1, z2 + 1):
                n_, s_, w_, e_ = z == z1, z == z2, x == x1, x == x2
                if not (n_ or s_ or w_ or e_):
                    S.set(x, y, z, tiles)
                    continue
                f = "south" if n_ else "north" if s_ else "east" if w_ else "west"
                S.set(x, y, z, B(RST, facing=f, half="bottom", shape="straight", waterlogged=False))
    S.fill(12, 39, 8, 12, 44, 8, B("polished_blackstone_wall"))   # cruz no topo
    S.fill(11, 42, 8, 13, 42, 8, B("polished_blackstone_wall"))
    # portas: entrada e nártex -> nave
    S.fill(11, 5, 4, 14, 9, 4, pil)
    S.air(12, 5, 4, 13, 8, 4)
    S.double_door(12, 5, 4, "spruce_door", "south")
    S.air(12, 5, 13, 13, 8, 13)
    S.double_door(12, 5, 13, "spruce_door", "south")
    for x in (12, 13):
        S.set(x, 7, 4, pane("red")); S.set(x, 8, 4, pane("orange"))
        S.set(x, 7, 13, pane("blue")); S.set(x, 8, 13, pane("light_blue"))
    S.chandelier(12, 8, 11, 1); S.chandelier(13, 8, 11, 1)

    # ------------------------------------------------------------------ CAPELA-MOR (x 8..17, z 37..43)
    def yc_c(x):
        return 16 + min(x - 8, 17 - x)
    S.fill(8, 5, 37, 17, 15, 43, wall)
    for x in range(9, 17):
        S.air(x, 5, 37, x, yc_c(x) - 1, 42)
        S.fill(x, 16, 43, x, yc_c(x) - 1, 43, wall)
    for z in range(37, 45):
        for x in range(8, 13):
            S.stairs(x, 16 + (x - 8), z, RST, "east")
        for x in range(13, 18):
            S.stairs(x, 16 + (17 - x), z, RST, "west")
    floor(9, 36, 16, 42)
    for x in range(9, 17):                                   # estrado + degrau
        for z in range(37, 43):
            S.set(x, 5, z, base)
        S.stairs(x, 5, 36, "stone_brick_stairs", "south")
    S.fill(11, 6, 40, 14, 6, 40, quartz)                     # altar
    for x in (11, 14):
        S.set(x, 7, 40, B("white_candle", candles=3, lit=True, waterlogged=False))
    S.set(12, 7, 40, carpet); S.set(13, 7, 40, carpet)
    S.fill(12, 6, 42, 13, 6, 42, quartz)                     # cruz atrás do altar
    S.fill(12, 7, 42, 13, 13, 42, B("stripped_spruce_log", axis="y"))
    S.fill(10, 11, 42, 15, 12, 42, B("stripped_spruce_log", axis="x"))
    S.set(12, 4, 41, B("reinforced_deepslate"))              # MARCADOR do spawn do Pucci (escondido sob o estrado)
    for i, y in enumerate(range(7, 15)):                     # vitral do fundo
        for x in range(10, 16):
            S.set(x, y, 43, pane(cols[(i + x) % len(cols)]))
    for z in (38, 40):                                       # bancos do coro
        S.stairs(9, 5, z, "spruce_stairs", "east")
        S.stairs(16, 5, z, "spruce_stairs", "west")
    for (x, z) in ((10, 41), (15, 41)):
        S.set(x, 5, z, pil); S.set(x, 6, z, lantern)
    return S


if __name__ == "__main__":
    s = build()
    print(len(s.g), "blocos")
