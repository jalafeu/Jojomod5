"""Mansão do DIO (Cairo, 1989) – estrutura com salão do trono / arena de boss.

Eixo de simetria: entre x=22 e x=23 (S.mx(x) = 45 - x). Frente da mansão = z pequeno.
Origem do template: canto (0,0,0). O chão do terreno fica em y=5 (ar em y=6).
"""
from builder import B, Structure, AIR

W, H, D = 46, 40, 41


def pane(color="red"):
    return B(f"{color}_stained_glass_pane")


def build():
    S = Structure(W, H, D)

    wall = B("deepslate_bricks")
    trim = B("polished_blackstone_bricks")
    pil = B("polished_blackstone")
    chis = B("chiseled_polished_blackstone")
    belt = B("red_nether_bricks")
    gold = B("gold_block")
    plank = B("dark_oak_planks")
    tiles = B("deepslate_tiles")
    pdeep = B("polished_deepslate")
    bwall = B("polished_blackstone_brick_wall")
    bars = B("iron_bars")
    LOOT = "jojomod:chests/dio_mansion"

    # ------------------------------------------------------------------ limpa + pódio
    S.air(0, 6, 0, 45, H - 1, 40)
    S.fill(0, 0, 2, 45, 5, 40, wall)
    S.fill(0, 6, 2, 45, 6, 40, trim)
    for x in range(0, 46):
        for z in range(2, 41):
            S.set(x, 7, z, pil if (x + z) % 4 == 0 else trim)
    # escadaria de entrada (sobe para +z => facing south)
    S.fill(18, 0, 1, 27, 5, 1, wall)
    for x in range(18, 28):
        S.stairs(x, 6, 1, "polished_blackstone_brick_stairs", "south")

    # balaústre do pódio + postes com lanterna
    posts = [(0, 2), (45, 2), (0, 40), (45, 40), (0, 21), (45, 21), (9, 2), (36, 2), (17, 2), (28, 2)]
    for x in range(0, 46):
        for z in (2, 40):
            if z == 2 and 18 <= x <= 27:
                continue
            S.set(x, 8, z, bwall)
    for z in range(2, 41):
        for x in (0, 45):
            S.set(x, 8, z, bwall)
    for (x, z) in posts:
        S.fill(x, 8, z, x, 9, z, pil)
        S.set(x, 10, z, B("lantern", hanging=False, waterlogged=False))

    # ------------------------------------------------------------------ corpo principal
    S.fill(5, 8, 8, 40, 21, 36, wall)
    S.air(6, 8, 9, 39, 13, 35)
    S.air(6, 15, 9, 39, 20, 35)
    S.fill(6, 14, 9, 39, 14, 35, plank)
    S.fill(6, 21, 9, 39, 21, 35, tiles)
    # piso térreo (xadrez)
    for x in range(6, 40):
        for z in range(9, 36):
            S.set(x, 7, z, pil if (x + z) % 2 == 0 else pdeep)

    # cintos vermelhos (y=14 e y=21) e base
    def ring(y, blk, x1=5, x2=40, z1=8, z2=36):
        for x in range(x1, x2 + 1):
            S.set(x, y, z1, blk); S.set(x, y, z2, blk)
        for z in range(z1, z2 + 1):
            S.set(x1, y, z, blk); S.set(x2, y, z, blk)
    ring(14, belt); ring(21, belt)
    ring(8, trim); ring(9, trim)

    # ------------------------------------------------------------------ salão do trono (arena)
    S.fill(16, 8, 14, 29, 26, 36, wall)

    def yc(x):  # altura do teto do salão na coluna x
        return 27 + min(x - 16, 29 - x)

    for x in range(17, 29):
        S.air(x, 8, 15, x, yc(x) - 1, 35)
        S.fill(x, 27, 14, x, yc(x) - 1, 14, wall)      # empena frontal
        S.fill(x, 27, 36, x, yc(x) - 1, 36, wall)      # empena traseira
    # telhado em V (sobe em direção ao centro)
    for z in range(13, 38):
        for x in range(16, 23):
            S.stairs(x, 27 + (x - 16), z, "deepslate_tile_stairs", "east")
        for x in range(23, 30):
            S.stairs(x, 27 + (29 - x), z, "deepslate_tile_stairs", "west")
        S.slab(22, 34, z, "deepslate_tile_slab"); S.slab(23, 34, z, "deepslate_tile_slab")
    # rosáceas (círculo ~6x6) nas duas empenas
    for zz in (14, 36):
        for x in range(20, 26):
            for y in range(26, 32):
                dx, dy = x - 22.5, y - 28.5
                if dx * dx + dy * dy <= 7.0:
                    inner = abs(dx) < 1 and abs(dy) < 1
                    S.set(x, y, zz, pane("yellow" if inner else "red"))
    # pilastras internas + janelas (clerestório e galeria)
    for z in (17, 21, 25, 29, 33):
        for x in (17, 28):
            S.fill(x, 8, z, x, yc(x) - 1, z, pil)
            S.set(x, 8, z, chis)
    for z in (19, 23, 27, 31):
        for x in (16, 29):
            for y in range(23, 27):
                S.set(x, y, z, pane("red"))
            for y in range(16, 20):
                S.set(x, y, z, bars)       # galeria do 2º andar olhando o salão
    # piso do salão: xadrez escuro + anel vermelho + núcleo dourado
    for x in range(17, 29):
        for z in range(15, 36):
            S.set(x, 7, z, trim if (x + z) % 2 == 0 else pil)
    cx, cz = 22.5, 22.5
    for x in range(17, 29):
        for z in range(15, 31):
            r = ((x - cx) ** 2 + (z - cz) ** 2) ** 0.5
            if 4.2 <= r <= 5.3:
                S.set(x, 7, z, belt)
            elif r < 1.6:
                S.set(x, 7, z, gold)
            elif 2.6 <= r <= 3.4:
                S.set(x, 7, z, chis)
    # tapete vermelho
    for x in range(21, 25):
        for z in range(15, 30):
            if 20 <= z <= 25:   # deixa o emblema central livre
                continue
            S.set(x, 8, z, B("red_carpet"))
    # estrado + trono
    S.fill(17, 8, 31, 28, 8, 35, trim)
    for x in range(17, 29):
        S.stairs(x, 8, 30, "polished_blackstone_brick_stairs", "south")
    S.fill(19, 9, 33, 26, 9, 35, pil)
    for x in range(19, 27):
        S.stairs(x, 9, 32, "polished_blackstone_brick_stairs", "south")
    S.fill(20, 10, 34, 25, 10, 34, AIR)
    S.stairs(22, 10, 34, "crimson_stairs", "south"); S.stairs(23, 10, 34, "crimson_stairs", "south")
    S.fill(21, 10, 35, 24, 15, 35, trim)
    S.fill(22, 16, 35, 23, 17, 35, chis)
    S.fill(21, 10, 35, 21, 17, 35, gold); S.fill(24, 10, 35, 24, 17, 35, gold)
    S.set(21, 18, 35, chis); S.set(24, 18, 35, chis)
    for x in (21, 24):
        S.set(x, 10, 34, B("polished_blackstone_brick_slab", type="bottom", waterlogged=False))
    S.set(20, 10, 35, B("lantern", hanging=False, waterlogged=False))   # sobre bloco cheio (x=20 y=9 é pil)
    S.set(25, 10, 35, B("lantern", hanging=False, waterlogged=False))
    S.set(22, 8, 34, B("reinforced_deepslate"))   # MARCADOR do spawn do boss (escondido sob o trono)
    # tochas do estrado
    for x in (19, 26):
        S.set(x, 10, 33, B("lantern", hanging=False, waterlogged=False))
    # lustres + estandartes
    for z in (18, 24, 30):
        for x in (22, 23):
            S.chandelier(x, z, 33, 6)
    for z in (19, 23, 27, 31):
        S.set(17, 11, z, B("red_wall_banner", facing="east"))
        S.set(28, 11, z, B("red_wall_banner", facing="west"))

    # ------------------------------------------------------------------ torres de canto
    def tower_box(x1, x2, z1, z2, ix1, ix2, iz1, iz2, ux1, ux2, uz1, uz2):
        S.fill2(x1, 8, z1, x2, 27, z2, wall)
        S.fill2(ix1, 8, iz1, ix2, 13, iz2, AIR)
        S.fill2(ix1, 15, iz1, ix2, 20, iz2, AIR)
        S.fill2(ix1, 22, iz1, ix2, 27, iz2, AIR)
        S.fill2(ux1, 8, uz1, ux2, 13, uz2, AIR)       # funde com o saguão
        S.fill2(ux1, 15, uz1, ux2, 20, uz2, AIR)
        S.fill2(ix1, 14, iz1, ix2, 14, iz2, plank)
        S.fill2(ix1, 21, iz1, ix2, 21, iz2, tiles)
        S.fill2(ux1, 14, uz1, ux2, 14, uz2, plank)
        S.fill2(ix1, 7, iz1, ix2, 7, iz2, pdeep)
    tower_box(2, 8, 5, 11, 3, 7, 6, 10, 6, 8, 9, 11)       # frente
    tower_box(2, 8, 33, 39, 3, 7, 34, 38, 6, 8, 33, 35)    # fundos
    # cintos nas torres + base
    for (z1, z2) in ((5, 11), (33, 39)):
        for y, blk in ((14, belt), (21, belt), (28, belt), (8, trim), (9, trim)):
            for x in range(2, 9):
                for z in range(z1, z2 + 1):
                    if x in (2, 8) or z in (z1, z2):
                        if S.get(x, y, z) == wall or S.get(x, y, z) == trim or S.get(x, y, z) == belt:
                            S.set2(x, y, z, blk)
    # topo das torres (y=28 tampa) e pirâmide
    for (z1, z2) in ((5, 11), (33, 39)):
        S.fill2(2, 28, z1, 8, 28, z2, wall)
        for i, (a, b_) in enumerate(((1, 9), (2, 8), (3, 7), (4, 6))):
            y = 29 + i
            zz1, zz2 = z1 - 1 + i + 0, z2 + 1 - i
            # camada i: retângulo x[a..b_]  z[zz1..zz2]  (shrink 1 por camada)
            for x in range(a, b_ + 1):
                for z in range(zz1, zz2 + 1):
                    edge_n, edge_s = z == zz1, z == zz2
                    edge_w, edge_e = x == a, x == b_
                    if not (edge_n or edge_s or edge_w or edge_e):
                        S.set2(x, y, z, tiles)
                        continue
                    if edge_n: f = "south"
                    elif edge_s: f = "north"
                    elif edge_w: f = "east"
                    else: f = "west"
                    S.set(x, y, z, B("deepslate_tile_stairs", facing=f, half="bottom", shape="straight", waterlogged=False))
                    S.set(S.mx(x), y, z, B("deepslate_tile_stairs", facing={"east": "west", "west": "east"}.get(f, f), half="bottom", shape="straight", waterlogged=False))
        cxm, czm = 5, (z1 + z2) // 2
        S.set2(5, 33, czm, tiles)
        S.fill2(5, 34, czm, 5, 36, czm, bwall)
        S.set2(5, 37, czm, B("lantern", hanging=False, waterlogged=False))

    # ------------------------------------------------------------------ divisórias
    for y0, y1 in ((8, 13), (15, 20)):
        S.fill(6, y0, 14, 39, y1, 14, wall)           # saguão | resto
    S.fill(6, 8, 25, 15, 13, 25, wall)                # alas térreas
    S.fill(30, 8, 25, 39, 13, 25, wall)

    # ------------------------------------------------------------------ portas
    dd = "dark_oak_door"
    # entrada principal (térreo) + sacada (2º andar)
    for y0 in (8, 15):
        S.fill(21, y0, 8, 24, y0 + 5, 8, trim)
        S.air(22, y0, 8, 23, y0 + 3, 8)
        S.double_door(22, y0, 8, dd, "south")
        for y in (y0 + 2, y0 + 3):
            S.set(22, y, 8, pane("red")); S.set(23, y, 8, pane("red"))
    # porta do salão
    S.fill(21, 8, 14, 24, 13, 14, trim)
    S.air(22, 8, 14, 23, 11, 14)
    S.double_door(22, 8, 14, dd, "south")
    for y in (10, 11):
        S.set(22, y, 14, pane("red")); S.set(23, y, 14, pane("red"))
    # portas das alas
    for x in (10, 35):
        for y0 in (8, 15):
            S.air(x, y0, 14, x, y0 + 1, 14)
            S.door(x, y0, 14, dd, "south", "left")
        S.air(x, 8, 25, x, 9, 25)
        S.door(x, 8, 25, dd, "south", "left")

    # ------------------------------------------------------------------ janelas + pilastras externas
    for x in (10, 14, 18):                                  # fachada
        for y in list(range(10, 14)) + list(range(17, 21)):
            S.set2(x, y, 8, pane("red"))
    for x in (12, 16):
        S.fill2(x, 8, 7, x, 21, 7, pil)
    for z in (17, 22, 28, 31):                              # laterais
        for y in list(range(10, 14)) + list(range(17, 21)):
            S.set2(5, y, z, pane("red"))
    for z in (15, 20, 25, 30):
        S.fill2(4, 8, z, 4, 21, z, pil)
    for x in (9, 12):                                       # fundos
        for y in list(range(10, 14)) + list(range(17, 21)):
            S.set2(x, y, 36, pane("red"))
    # janelas das torres
    for (cz_) in (8, 36):
        for y in list(range(10, 14)) + list(range(17, 21)) + list(range(23, 27)):
            S.set2(2, y, cz_, pane("red"))
    for y in list(range(10, 14)) + list(range(17, 21)) + list(range(23, 27)):
        S.set2(5, y, 5, pane("red"))
        S.set2(5, y, 39, pane("red"))

    # ------------------------------------------------------------------ portico e sacada
    for x in (19, 21, 24, 26):
        S.fill(x, 8, 3, x, 13, 3, pil)
        S.set(x, 8, 3, chis); S.set(x, 13, 3, chis)
    S.fill(18, 14, 3, 27, 14, 7, trim)
    for x in range(18, 28):
        S.set(x, 15, 3, bwall)
    for z in range(3, 8):
        S.set(18, 15, z, bwall); S.set(27, 15, z, bwall)
    for (x, z) in ((18, 3), (27, 3)):
        S.set(x, 15, z, pil); S.set(x, 16, z, B("lantern", hanging=False, waterlogged=False))
    S.chandelier(20, 5, 14, 1); S.chandelier(25, 5, 14, 1)
    # carpete na entrada
    for z in range(9, 14):
        for x in (22, 23):
            S.set(x, 8, z, B("red_carpet"))

    # ------------------------------------------------------------------ parapeito do terraço
    for x in range(9, 37):
        S.set(x, 22, 8, bwall)
        if x % 2 == 0: S.set(x, 23, 8, B("polished_blackstone_brick_slab", type="bottom", waterlogged=False))
    for z in range(12, 33):
        S.set2(5, 22, z, bwall)
        if z % 2 == 0: S.set2(5, 23, z, B("polished_blackstone_brick_slab", type="bottom", waterlogged=False))
    for x in list(range(9, 16)) + list(range(30, 37)):
        S.set(x, 22, 36, bwall)
        if x % 2 == 0: S.set(x, 23, 36, B("polished_blackstone_brick_slab", type="bottom", waterlogged=False))

    # ------------------------------------------------------------------ escadas grandes (saguão -> 2º andar)
    # esquerda: sobe para +x
    for i in range(7):
        for z in (9, 10):
            S.stairs(8 + i, 8 + i, z, "dark_oak_stairs", "east")
    for i in range(4, 7):
        for z in (9, 10):
            if i < 6:
                S.set(8 + i, 14, z, AIR)
    for x in range(12, 15):
        for z in (9, 10):
            if S.get(x, 14, z)[0] == "minecraft:dark_oak_planks":
                S.set(x, 14, z, AIR)
    for i in range(7):                       # espelho
        for z in (9, 10):
            S.set(S.mx(8 + i), 8 + i, z, B("dark_oak_stairs", facing="west", half="bottom", shape="straight", waterlogged=False))
    for x in range(12, 15):
        for z in (9, 10):
            S.set(S.mx(x), 14, z, AIR)
    # reimpor os degraus finais (y=14, x=14) que o corte apagou
    for z in (9, 10):
        S.stairs(14, 14, z, "dark_oak_stairs", "east")
        S.set(S.mx(14), 14, z, B("dark_oak_stairs", facing="west", half="bottom", shape="straight", waterlogged=False))
    # grades de proteção do vão
    fence = B("dark_oak_fence")
    for x in range(12, 15):
        S.set2(x, 15, 11, fence)
    for z in (9, 10):
        S.set2(11, 15, z, fence)

    # ------------------------------------------------------------------ SALAS (térreo)
    bookshelf = B("bookshelf")
    chair = lambda x, y, z, f: S.stairs(x, y, z, "dark_oak_stairs", f)
    # ---- biblioteca (ala esquerda, frente)
    for x in list(range(6, 10)) + list(range(11, 16)):
        S.fill(x, 8, 15, x, 11, 15, bookshelf)
        S.fill(x, 8, 24, x, 11, 24, bookshelf)
    for x in range(8, 14):
        for z in range(18, 22):
            S.set(x, 8, z, B("red_carpet"))
    for (x, z) in ((9, 19), (12, 19), (9, 21), (12, 21)):
        S.set(x, 8, z, B("dark_oak_fence")); S.set(x, 9, z, B("dark_oak_pressure_plate", powered=False))
    S.set(10, 8, 17, B("lectern", facing="south", has_book=False, powered=False))
    S.set(11, 8, 17, B("lectern", facing="south", has_book=False, powered=False))
    chair(10, 8, 22, "south"); chair(11, 8, 22, "south")
    S.chandelier(10, 20, 14, 1); S.chandelier(11, 20, 14, 1)
    S.chest(6, 8, 20, "east", LOOT)
    # ---- sala de jantar (ala esquerda, fundos)
    for z in range(28, 34):
        S.set(10, 8, z, B("dark_oak_slab", type="top", waterlogged=False))
        S.set(11, 8, z, B("dark_oak_slab", type="top", waterlogged=False))
    for z in (28, 30, 32):
        chair(9, 8, z, "west"); chair(12, 8, z, "east")
    chair(10, 8, 34, "north"); S.set(11, 8, 34, B("dark_oak_stairs", facing="north", half="bottom", shape="straight", waterlogged=False))
    for z in (29, 32):
        S.set(10, 9, z, B("red_candle", candles=3, lit=True, waterlogged=False))
        S.set(11, 9, z, B("red_candle", candles=2, lit=True, waterlogged=False))
    S.chandelier(10, 30, 14, 1); S.chandelier(11, 30, 14, 1)
    S.chest(6, 8, 33, "east", LOOT)
    # ---- sala de troféus (ala direita, frente)  [espelhada em decor própria]
    for (x, z) in ((32, 17), (37, 17), (32, 22), (37, 22)):
        S.fill(x, 8, z, x, 8, z, pil)
        S.set(x, 9, z, gold)
        S.set(x, 10, z, B("lantern", hanging=False, waterlogged=False))
    for x in range(31, 39):
        S.set(x, 8, 19, B("red_carpet")); S.set(x, 8, 20, B("red_carpet"))
    S.set(35, 8, 16, B("grindstone", face="floor", facing="south"))
    S.set(36, 8, 16, B("anvil", facing="south"))
    S.set(33, 8, 16, B("anvil", facing="south"))
    S.chest(39, 8, 20, "west", LOOT)
    S.chest(39, 8, 21, "west", LOOT)
    S.chandelier(34, 20, 14, 1); S.chandelier(37, 20, 14, 1)
    # ---- quarto do DIO (ala direita, fundos)
    S.bed(36, 8, 33, "north", "red")
    S.bed(37, 8, 33, "north", "red")
    for z in range(27, 35):
        S.set(38, 8, z, bookshelf); None if z in (29, 30) else S.set(38, 9, z, bookshelf)
    for x in range(31, 37):
        S.set(x, 8, 27, B("red_carpet")); S.set(x, 8, 28, B("red_carpet"))
    S.chest(39, 8, 28, "west", LOOT)
    S.set(31, 8, 34, pil); S.set(31, 9, 34, B("red_candle", candles=4, lit=True, waterlogged=False))
    S.chandelier(34, 30, 14, 1)

    # ------------------------------------------------------------------ SALAS (2º andar)
    # esquerda: dormitórios (camas junto à parede do salão; barras do salão em z=19,23,27,31)
    for z in (17, 21, 25, 29, 33):
        S.bed(14, 15, z, "east", "red" if z % 8 == 5 else "black")
    for z in (19, 23, 27, 31):
        S.set(6, 15, z, B("dark_oak_fence")); S.set(6, 16, z, B("dark_oak_pressure_plate", powered=False))
    S.chest(7, 15, 16, "south", LOOT)
    S.chandelier(10, 20, 21, 1); S.chandelier(10, 30, 21, 1)
    # direita: estúdio
    for z in range(16, 34):
        S.set(39, 15, z, bookshelf)
        if z % 3 != 0:
            S.set(39, 16, z, bookshelf)
    for x in range(32, 38):
        S.set(x, 15, 24, B("red_carpet")); S.set(x, 15, 25, B("red_carpet"))
    for (x, z) in ((33, 22), (36, 22), (33, 27), (36, 27)):
        S.set(x, 15, z, B("dark_oak_fence")); S.set(x, 16, z, B("dark_oak_pressure_plate", powered=False))
    S.chest(31, 15, 16, "south", LOOT)
    S.chest(38, 15, 34, "north", LOOT)
    S.chandelier(35, 20, 21, 1); S.chandelier(35, 30, 21, 1)
    # corredor sobre o saguão
    S.chandelier(19, 11, 21, 1); S.chandelier(26, 11, 21, 1)
    S.chandelier(19, 11, 14, 1); S.chandelier(26, 11, 14, 1)
    # ... e luz no saguão térreo
    return S


if __name__ == "__main__":
    s = build()
    print(len(s.g), "blocos")
