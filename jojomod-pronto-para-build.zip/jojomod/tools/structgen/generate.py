#!/usr/bin/env python3
"""Gera os arquivos .nbt das estruturas do JoJo Mod.

Uso (na raiz do projeto):   python3 tools/structgen/generate.py
Saída: src/main/resources/data/jojomod/structures/{dio_mansion,pucci_church}.nbt
Edite dio_mansion.py / pucci_church.py e rode de novo para alterar as construções.
"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import dio_mansion, pucci_church, nbt  # noqa: E402

OUT = os.path.normpath(os.path.join(HERE, "..", "..", "src", "main", "resources", "data", "jojomod", "structures"))


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, mod in (("dio_mansion", dio_mansion), ("pucci_church", pucci_church)):
        s = mod.build()
        path = os.path.join(OUT, name + ".nbt")
        size = s.save(path)
        back = nbt.loads(open(path, "rb").read())
        assert len(back["blocks"]) == len(s.g)
        print(f"{name}: {len(s.g)} blocos, {s.size}, {size/1024:.0f} KB -> {path}")


if __name__ == "__main__":
    main()
