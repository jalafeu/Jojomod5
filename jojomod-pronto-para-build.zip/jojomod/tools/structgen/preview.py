"""Pré-visualização: cortes ASCII por camada Y e render isométrico simples (PNG)."""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

COL = {
    "deepslate": (0.25, 0.25, 0.28), "blackstone": (0.15, 0.13, 0.16), "nether_brick": (0.55, 0.12, 0.12),
    "gold": (0.95, 0.8, 0.2), "planks": (0.35, 0.22, 0.12), "glass": (0.9, 0.2, 0.25), "stone": (0.55, 0.55, 0.55),
    "quartz": (0.92, 0.9, 0.85), "spruce": (0.38, 0.27, 0.15), "other": (0.5, 0.5, 0.6), "carpet": (0.7, 0.1, 0.1),
    "yellow": (0.95, 0.85, 0.2), "blue": (0.2, 0.35, 0.9), "purple": (0.6, 0.25, 0.8), "light": (1, 0.9, 0.5),
}


def color_of(name):
    n = name.split(":")[1]
    if "stained_glass" in n:
        for c in ("yellow", "blue", "purple"):
            if c in n:
                return COL[c]
        return COL["glass"]
    if "carpet" in n or "banner" in n or "red_bed" in n: return COL["carpet"]
    if "lantern" in n or "candle" in n: return COL["light"]
    if "gold" in n: return COL["gold"]
    if "nether_brick" in n: return COL["nether_brick"]
    if "blackstone" in n: return COL["blackstone"]
    if "deepslate" in n: return COL["deepslate"]
    if "dark_oak" in n or "oak" in n and "spruce" not in n: return COL["planks"]
    if "spruce" in n: return COL["spruce"]
    if "quartz" in n: return COL["quartz"]
    if "stone" in n: return COL["stone"]
    return COL["other"]


def iso(S, path, az=35):
    sx, sy, sz = S.size
    blocks = [(k, color_of(b[0])) for k, b in S.g.items() if b[0] != "minecraft:air"]
    ang = np.radians(az)
    ca, sa = np.cos(ang), np.sin(ang)
    cx, cz = sx / 2, sz / 2
    def proj(x, y, z):
        xr = (x - cx) * ca - (z - cz) * sa
        zr = (x - cx) * sa + (z - cz) * ca
        return xr - zr * 0.0, y * 0.9 + zr * 0.45 * -1 + 0, zr
    # pintor: ordena por profundidade
    items = []
    occ = set(k for k, _ in blocks)
    for (x, y, z), c in blocks:
        # só desenha blocos com alguma face exposta (cima, ou lados voltados à câmera)
        if (x, y + 1, z) in occ and (x + 1, y, z) in occ and (x, y, z + 1) in occ and (x - 1, y, z) in occ and (x, y, z - 1) in occ:
            continue
        xr = (x - cx) * ca - (z - cz) * sa
        zr = (x - cx) * sa + (z - cz) * ca
        items.append((zr, y, xr, c))
    items.sort(key=lambda t: (t[0], t[1]))
    fig, ax = plt.subplots(figsize=(14, 11), dpi=110)
    ax.set_facecolor((0.6, 0.78, 0.95))
    for zr, y, xr, c in items:
        X, Y = xr, y - zr * 0.5
        top = [(X - .5, Y + 1), (X + .5, Y + 1), (X + .5 + 0, Y + 1.0 + .5), (X - .5, Y + 1.5)]
        # face frontal
        front = [(X - .5, Y), (X + .5, Y), (X + .5, Y + 1), (X - .5, Y + 1)]
        topf = [(X - .5, Y + 1), (X + .5, Y + 1), (X + .5, Y + 1.5), (X - .5, Y + 1.5)]
        ax.add_patch(Polygon(front, closed=True, fc=tuple(v * 0.8 for v in c), ec="none"))
        ax.add_patch(Polygon(topf, closed=True, fc=c, ec="none"))
    xs = [i[2] for i in items]; ys = [i[1] - i[0] * 0.5 for i in items]
    ax.set_xlim(min(xs) - 2, max(xs) + 2); ax.set_ylim(min(ys) - 2, max(ys) + 4)
    ax.set_aspect("equal"); ax.axis("off")
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)


def layer(S, y, sym=None):
    sx, _, sz = S.size
    sym = sym or {}
    rows = []
    for z in range(sz):
        row = ""
        for x in range(sx):
            b = S.g.get((x, y, z))
            if b is None or b[0] == "minecraft:air":
                row += "."
            else:
                n = b[0].split(":")[1]
                ch = "#"
                if "stairs" in n: ch = "s"
                elif "slab" in n: ch = "_"
                elif "pane" in n or "bars" in n: ch = "="
                elif "door" in n: ch = "D"
                elif "carpet" in n: ch = "c"
                elif "lantern" in n or "candle" in n: ch = "*"
                elif "chain" in n: ch = "|"
                elif "wall" in n or "fence" in n: ch = "+"
                elif "chest" in n: ch = "C"
                elif "bed" in n: ch = "b"
                elif "gold" in n: ch = "G"
                elif "bookshelf" in n: ch = "B"
                row += ch
        rows.append(row)
    return "\n".join(rows)


if __name__ == "__main__":
    mod = sys.argv[1]
    m = __import__(mod)
    S = m.build()
    for y in [int(a) for a in sys.argv[2:]]:
        print(f"--- y={y}"); print(layer(S, y))
