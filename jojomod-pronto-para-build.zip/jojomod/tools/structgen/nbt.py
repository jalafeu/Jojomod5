"""Escritor mínimo de NBT (formato de arquivo de estrutura do Minecraft, .nbt = gzip)."""
import gzip, struct

END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTEARRAY, STRING, LIST, COMPOUND, INTARRAY, LONGARRAY = range(13)


class Int(int):
    """Marca um inteiro como TAG_Int."""


class Byte(int):
    pass


def _w_str(out, s):
    b = s.encode("utf-8")
    out.append(struct.pack(">H", len(b)))
    out.append(b)


def _tag_id(v):
    if isinstance(v, bool):
        return BYTE
    if isinstance(v, Byte):
        return BYTE
    if isinstance(v, (Int, int)):
        return INT
    if isinstance(v, float):
        return DOUBLE
    if isinstance(v, str):
        return STRING
    if isinstance(v, dict):
        return COMPOUND
    if isinstance(v, list):
        return LIST
    raise TypeError(type(v))


def _w_payload(out, v):
    t = _tag_id(v)
    if t == BYTE:
        out.append(struct.pack(">b", int(v)))
    elif t == INT:
        out.append(struct.pack(">i", int(v)))
    elif t == DOUBLE:
        out.append(struct.pack(">d", v))
    elif t == STRING:
        _w_str(out, v)
    elif t == COMPOUND:
        for k, val in v.items():
            out.append(struct.pack(">B", _tag_id(val)))
            _w_str(out, k)
            _w_payload(out, val)
        out.append(b"\x00")
    elif t == LIST:
        if not v:
            out.append(struct.pack(">Bi", END, 0))
        else:
            et = _tag_id(v[0])
            out.append(struct.pack(">Bi", et, len(v)))
            for e in v:
                _w_payload(out, e)


def dumps(root: dict) -> bytes:
    out = [struct.pack(">B", COMPOUND)]
    _w_str(out, "")
    _w_payload(out, root)
    return gzip.compress(b"".join(out), 9, mtime=0)


# ---- leitor simples, usado só para validar o arquivo gerado ----
def loads(data: bytes):
    import io
    buf = io.BytesIO(gzip.decompress(data))

    def rd(fmt):
        s = struct.calcsize(fmt)
        return struct.unpack(fmt, buf.read(s))[0]

    def rstr():
        n = rd(">H")
        return buf.read(n).decode("utf-8")

    def payload(t):
        if t == BYTE: return rd(">b")
        if t == SHORT: return rd(">h")
        if t == INT: return rd(">i")
        if t == LONG: return rd(">q")
        if t == FLOAT: return rd(">f")
        if t == DOUBLE: return rd(">d")
        if t == STRING: return rstr()
        if t == COMPOUND:
            d = {}
            while True:
                tt = rd(">B")
                if tt == END:
                    return d
                k = rstr()
                d[k] = payload(tt)
        if t == LIST:
            et = rd(">B"); n = rd(">i")
            return [payload(et) for _ in range(n)]
        raise ValueError(t)

    assert rd(">B") == COMPOUND
    rstr()
    return payload(COMPOUND)
