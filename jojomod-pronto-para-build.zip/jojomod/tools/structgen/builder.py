"""Construtor de estruturas voxel -> arquivo .nbt de estrutura (Minecraft 1.20.1)."""
import nbt

DATA_VERSION = 3465  # 1.20.1
AIR = ("minecraft:air", ())

DIRS = {"north": (0, 0, -1), "south": (0, 0, 1), "west": (-1, 0, 0), "east": (1, 0, 0)}
OPP = {"north": "south", "south": "north", "west": "east", "east": "west"}
CCW = {"north": "west", "west": "south", "south": "east", "east": "north"}  # rotateYCounterclockwise
CW = {v: k for k, v in CCW.items()}


def B(name, **props):
    if ":" not in name:
        name = "minecraft:" + name
    return (name, tuple(sorted((k, str(v).lower() if isinstance(v, bool) else str(v)) for k, v in props.items())))


def props(b):
    return dict(b[1])


def with_props(b, **kw):
    p = props(b)
    for k, v in kw.items():
        p[k] = str(v).lower() if isinstance(v, bool) else str(v)
    return (b[0], tuple(sorted(p.items())))


_NOT_FULL = ("stairs", "slab", "pane", "fence", "wall", "lantern", "chain", "carpet", "candle", "door",
             "trapdoor", "ladder", "torch", "bars", "bell", "campfire", "button", "banner", "head",
             "pot", "anvil", "lectern", "brewing", "chest", "cauldron", "lever", "rod", "grindstone",
             "cake", "bed", "air", "plate", "rail", "flower", "rose", "sign", "table", "bookshelf_x")


def full_cube(b):
    n = b[0].split(":")[1]
    if n == "air":
        return False
    return not any(s in n for s in _NOT_FULL)


def is_pane(b):
    n = b[0]
    return n.endswith("_pane") or n == "minecraft:iron_bars"


def is_stairs(b):
    return b[0].endswith("_stairs")


def mirror_block(b):
    p = props(b)
    swap = {"east": "west", "west": "east"}
    if "facing" in p and p["facing"] in swap:
        p["facing"] = swap[p["facing"]]
    if "hinge" in p:
        p["hinge"] = "right" if p["hinge"] == "left" else "left"
    if "shape" in p and p["shape"].endswith(("_left", "_right")):
        p["shape"] = p["shape"].replace("_left", "_L").replace("_right", "_left").replace("_L", "_right")
    return (b[0], tuple(sorted(p.items())))


class Structure:
    def __init__(self, sx, sy, sz):
        self.size = (sx, sy, sz)
        self.g = {}
        self.be = {}  # (x,y,z) -> nbt dict
        self.mirror_sum = sx - 1

    # ---------- básicos ----------
    def inb(self, x, y, z):
        return 0 <= x < self.size[0] and 0 <= y < self.size[1] and 0 <= z < self.size[2]

    def set(self, x, y, z, b, be=None):
        if isinstance(b, str):
            b = B(b)
        if not self.inb(x, y, z):
            raise IndexError((x, y, z, b))
        self.g[(x, y, z)] = b
        if be is not None:
            self.be[(x, y, z)] = be
        elif (x, y, z) in self.be:
            del self.be[(x, y, z)]

    def get(self, x, y, z):
        return self.g.get((x, y, z), AIR)

    def solid(self, x, y, z):
        return full_cube(self.get(x, y, z))

    def fill(self, x1, y1, z1, x2, y2, z2, b):
        if isinstance(b, str):
            b = B(b)
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for z in range(min(z1, z2), max(z1, z2) + 1):
                    self.set(x, y, z, b)

    def air(self, x1, y1, z1, x2, y2, z2):
        self.fill(x1, y1, z1, x2, y2, z2, AIR)

    def frame(self, x1, y1, z1, x2, y2, z2, b):
        """Caixa oca (só as 6 faces)."""
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                for z in range(z1, z2 + 1):
                    if x in (x1, x2) or y in (y1, y2) or z in (z1, z2):
                        self.set(x, y, z, b)

    # ---------- espelhamento (eixo X) ----------
    def mx(self, x):
        return self.mirror_sum - x

    def set2(self, x, y, z, b, be=None):
        """Coloca o bloco e o espelho dele (simetria em X)."""
        if isinstance(b, str):
            b = B(b)
        self.set(x, y, z, b, be)
        self.set(self.mx(x), y, z, mirror_block(b), be)

    def fill2(self, x1, y1, z1, x2, y2, z2, b):
        if isinstance(b, str):
            b = B(b)
        self.fill(x1, y1, z1, x2, y2, z2, b)
        self.fill(self.mx(x1), y1, z1, self.mx(x2), y2, z2, mirror_block(b))

    # ---------- peças comuns ----------
    def stairs(self, x, y, z, name, facing, half="bottom"):
        self.set(x, y, z, B(name, facing=facing, half=half, shape="straight", waterlogged=False))

    def slab(self, x, y, z, name, typ="bottom"):
        self.set(x, y, z, B(name, type=typ, waterlogged=False))

    def door(self, x, y, z, name, facing, hinge="left", open_=False):
        self.set(x, y, z, B(name, facing=facing, half="lower", hinge=hinge, open=open_, powered=False))
        self.set(x, y + 1, z, B(name, facing=facing, half="upper", hinge=hinge, open=open_, powered=False))

    def double_door(self, x, y, z, name, facing):
        """Porta dupla num plano Z (x e x+1), olhando para `facing` (north/south)."""
        # jogador olhando `facing`: esquerda = rotateYCCW(facing)
        left = CCW[facing]
        dx = DIRS[left][0]
        # porta mais à esquerda tem hinge left
        if dx < 0:
            xl, xr = x, x + 1
        else:
            xl, xr = x + 1, x
        self.door(xl, y, z, name, facing, "left")
        self.door(xr, y, z, name, facing, "right")

    def chandelier(self, x, z, ceil_y, length, lantern="lantern"):
        for i in range(1, length + 1):
            self.set(x, ceil_y - i, z, B("chain", axis="y", waterlogged=False))
        self.set(x, ceil_y - length - 1, z, B(lantern, hanging=True, waterlogged=False))

    def chest(self, x, y, z, facing, loot):
        self.set(x, y, z, B("chest", facing=facing, type="single", waterlogged=False),
                 be={"id": "minecraft:chest", "LootTable": loot})

    def bed(self, x, y, z, facing, color="red"):
        """(x,y,z) = pé da cama; cabeça fica na direção `facing`."""
        dx, _, dz = DIRS[facing]
        self.set(x, y, z, B(f"{color}_bed", facing=facing, part="foot", occupied=False))
        self.set(x + dx, y, z + dz, B(f"{color}_bed", facing=facing, part="head", occupied=False))

    # ---------- pós-processamento (conexões que o jogo calcularia ao colocar) ----------
    def _nb(self, x, y, z, d):
        dx, dy, dz = DIRS[d]
        return self.get(x + dx, y + dy, z + dz)

    def _side_solid(self, x, y, z, d):
        b = self._nb(x, y, z, d)
        return full_cube(b)

    def postprocess(self):
        cells = list(self.g.items())
        # painéis / grades
        for (x, y, z), b in cells:
            if is_pane(b):
                p = props(b)
                for d in DIRS:
                    nb = self._nb(x, y, z, d)
                    p[d] = "true" if (is_pane(nb) or full_cube(nb) or nb[0].endswith("_wall")) else "false"
                self.g[(x, y, z)] = (b[0], tuple(sorted(p.items())))
            elif b[0].endswith("_fence"):
                p = props(b)
                for d in DIRS:
                    nb = self._nb(x, y, z, d)
                    same = nb[0] == b[0]
                    gate = nb[0].endswith("_fence_gate")
                    p[d] = "true" if (same or gate or full_cube(nb)) else "false"
                self.g[(x, y, z)] = (b[0], tuple(sorted(p.items())))
        # paredes (de cima para baixo para resolver "up")
        walls = sorted([(k, b) for k, b in self.g.items() if b[0].endswith("_wall")], key=lambda kb: -kb[0][1])
        for (x, y, z), b in walls:
            p = props(b)
            conn = {}
            for d in DIRS:
                nb = self._nb(x, y, z, d)
                ok = nb[0].endswith("_wall") or full_cube(nb) or nb[0].endswith("_fence_gate")
                conn[d] = ok
                p[d] = "low" if ok else "none"
            n = sum(conn.values())
            straight = n == 2 and ((conn["north"] and conn["south"]) or (conn["east"] and conn["west"]))
            above = self.get(x, y + 1, z)
            if above[0].endswith("_wall"):
                up = props(above).get("up") == "true" or not straight
            elif above[0] != "minecraft:air":
                up = True
            else:
                up = not straight
            p["up"] = "true" if up else "false"
            self.g[(x, y, z)] = (b[0], tuple(sorted(p.items())))
        # escadas
        for (x, y, z), b in cells:
            if not is_stairs(b):
                continue
            self.g[(x, y, z)] = with_props(b, shape=self._stair_shape(x, y, z, b))

    def _stair_shape(self, x, y, z, b):
        p = props(b)
        f, half = p["facing"], p["half"]

        def stairs_at(d):
            nb = self._nb(x, y, z, d)
            return nb if is_stairs(nb) else None

        def diff_orient(d):
            nb = self._nb(x, y, z, d)
            if not is_stairs(nb):
                return True
            q = props(nb)
            return q["facing"] != f or q["half"] != half

        axis = lambda d: "x" if d in ("east", "west") else "z"
        nb = stairs_at(f)
        if nb is not None and props(nb)["half"] == half:
            f2 = props(nb)["facing"]
            if axis(f2) != axis(f) and diff_orient(OPP[f2]):
                return "outer_left" if f2 == CCW[f] else "outer_right"
        nb = stairs_at(OPP[f])
        if nb is not None and props(nb)["half"] == half:
            f3 = props(nb)["facing"]
            if axis(f3) != axis(f) and diff_orient(f3):
                return "inner_left" if f3 == CCW[f] else "inner_right"
        return "straight"

    # ---------- saída ----------
    def to_nbt(self):
        self.postprocess()
        palette, idx = [], {}
        blocks = []
        for (x, y, z), b in sorted(self.g.items(), key=lambda kv: (kv[0][1], kv[0][2], kv[0][0])):
            if b not in idx:
                idx[b] = len(palette)
                entry = {"Name": b[0]}
                if b[1]:
                    entry["Properties"] = {k: v for k, v in b[1]}
                palette.append(entry)
            e = {"pos": [nbt.Int(x), nbt.Int(y), nbt.Int(z)], "state": nbt.Int(idx[b])}
            if (x, y, z) in self.be:
                e["nbt"] = self.be[(x, y, z)]
            blocks.append(e)
        return {
            "DataVersion": nbt.Int(DATA_VERSION),
            "size": [nbt.Int(s) for s in self.size],
            "palette": palette,
            "blocks": blocks,
            "entities": [],
        }

    def save(self, path):
        data = nbt.dumps(self.to_nbt())
        with open(path, "wb") as f:
            f.write(data)
        return len(data)
