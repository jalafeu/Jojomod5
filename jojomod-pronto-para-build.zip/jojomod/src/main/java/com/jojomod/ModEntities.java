package com.jojomod;

import com.jojomod.entity.StandEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<StandEntity> STAND = Registry.register(
        Registries.ENTITY_TYPE,
        new Identifier(JojoMod.MOD_ID, "stand"),
        FabricEntityTypeBuilder.<StandEntity>create(SpawnGroup.MISC, StandEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
            .trackRangeChunks(8)
            .trackedUpdateRate(1)
            .build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(STAND, MobEntity.createMobAttributes());
    }
}
