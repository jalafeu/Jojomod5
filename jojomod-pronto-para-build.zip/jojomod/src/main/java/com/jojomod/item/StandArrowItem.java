package com.jojomod.item;

import com.jojomod.StandManager;
import com.jojomod.StandType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Fere o jogador e desperta um Stand aleatório (sempre diferente do atual). */
public class StandArrowItem extends Item {
    public StandArrowItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            if (sp.getHealth() <= 5f && !sp.getAbilities().creativeMode) {
                sp.sendMessage(Text.translatable("message.jojomod.arrow_weak"), true);
                return TypedActionResult.fail(stack);
            }
            sp.damage(world.getDamageSources().magic(), 4.0f);
            StandType current = StandManager.getStand(sp);
            StandType[] all = StandType.values();
            StandType next;
            do {
                next = all[world.random.nextInt(all.length)];
            } while (next == current && all.length > 1);
            StandManager.setStand(sp, next);
            sp.sendMessage(Text.translatable("message.jojomod.awakened", Text.translatable("stand.jojomod." + next.id)), true);
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
