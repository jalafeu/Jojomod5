package com.jojomod;

import com.jojomod.entity.StandEntity;
import com.jojomod.net.ModNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JojoMod implements ModInitializer {
    public static final String MOD_ID = "jojomod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        ModNetworking.registerServer();
        ModCommands.register();

        // Com o stand fora, quem soca é o stand: o soco do próprio jogador em entidades é cancelado.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
            StandEntity.findFor(player) != null ? ActionResult.FAIL : ActionResult.PASS);

        LOGGER.info("JoJo Mod carregado! Menacing...");
    }
}
