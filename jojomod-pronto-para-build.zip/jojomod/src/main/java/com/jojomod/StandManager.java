package com.jojomod;

import com.jojomod.entity.StandEntity;
import com.jojomod.net.ModNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StandManager {
    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();

    public static StandType getStand(ServerPlayerEntity p) {
        return StandState.get(p.getServer()).get(p.getUuid());
    }

    public static void setStand(ServerPlayerEntity p, StandType t) {
        StandState.get(p.getServer()).set(p.getUuid(), t);
        StandEntity old = StandEntity.findFor(p);
        if (old != null) old.discard();
        ModNetworking.sendSync(p);
    }

    /** Tecla Z: invoca ou guarda o stand. */
    public static void toggleSummon(ServerPlayerEntity p) {
        StandType t = getStand(p);
        if (t == null) {
            p.sendMessage(Text.translatable("message.jojomod.no_stand"), true);
            return;
        }
        StandEntity existing = StandEntity.findFor(p);
        if (existing != null) {
            existing.discard();
            p.sendMessage(Text.translatable("message.jojomod.dismiss"), true);
            return;
        }
        StandEntity s = new StandEntity(ModEntities.STAND, p.getWorld());
        s.setOwner(p);
        s.setStandType(t);
        s.refreshPositionAndAngles(p.getX(), p.getY(), p.getZ(), p.getYaw(), 0f);
        p.getWorld().spawnEntity(s);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.PLAYERS, 1.5f, 0.8f);
        p.sendMessage(Text.translatable("message.jojomod.summon", Text.translatable("stand.jojomod." + t.id)), true);
    }

    /** Teclas de habilidade (slot 1 a 5). */
    public static void useAbility(ServerPlayerEntity p, int slot) {
        if (slot < 1 || slot > 5) return;
        StandType t = getStand(p);
        StandEntity s = StandEntity.findFor(p);
        if (t == null || s == null) {
            p.sendMessage(Text.translatable("message.jojomod.need_stand"), true);
            return;
        }
        long now = p.getWorld().getTime();
        long[] cd = COOLDOWNS.computeIfAbsent(p.getUuid(), k -> new long[StandType.values().length * 6]);
        int idx = t.ordinal() * 6 + slot;
        if (cd[idx] > now) {
            p.sendMessage(Text.translatable("message.jojomod.cooldown", (cd[idx] - now + 19) / 20), true);
            return;
        }
        if (StandAbilities.use(s, p, t, slot)) {
            int ticks = t.cooldowns[slot - 1];
            cd[idx] = now + ticks;
            ModNetworking.sendCooldown(p, slot, ticks);
            p.sendMessage(Text.translatable("shout.jojomod." + t.id + "." + slot), true);
        }
    }
}
