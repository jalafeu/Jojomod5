package com.jojomod;

public enum StandType {
    //             id                punch  cooldowns dos slots 1..5 (ticks)
    STAR_PLATINUM("star_platinum",   4.0f, 160, 100, 200, 500, 400),
    THE_WORLD("the_world",           4.0f, 160, 160, 240, 700, 100),
    CRAZY_DIAMOND("crazy_diamond",   3.0f, 160, 200, 200, 400, 600),
    GOLD_EXPERIENCE("gold_experience", 3.0f, 160, 200, 220, 300, 300);

    public final String id;
    public final float punchDamage;
    public final int[] cooldowns;

    StandType(String id, float punchDamage, int... cooldowns) {
        this.id = id;
        this.punchDamage = punchDamage;
        this.cooldowns = cooldowns;
    }

    public static StandType byOrdinal(int i) {
        StandType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }

    public static StandType byId(String id) {
        for (StandType t : values()) if (t.id.equals(id)) return t;
        return null;
    }
}
