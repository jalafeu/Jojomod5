package com.jojomod;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.structure.Structure;

/**
 * Chaves das estruturas do mod (definidas em data/jojomod/worldgen/structure/*.json).
 *
 * Marcadores para o futuro boss / NPC: cada estrutura tem 1 bloco de reinforced_deepslate escondido
 * (indestrutível fora do criativo). Procure esse bloco dentro da caixa da estrutura para achar o ponto de spawn:
 *  - Mansão do DIO:   marcador no estrado do trono; o boss nasce 2 blocos acima, de frente para o salão.
 *  - Igreja do Pucci: marcador sob o estrado do altar; o Pucci nasce 2 blocos acima, diante do altar.
 */
public final class ModStructures {
    public static final RegistryKey<Structure> DIO_MANSION =
        RegistryKey.of(RegistryKeys.STRUCTURE, new Identifier(JojoMod.MOD_ID, "dio_mansion"));
    public static final RegistryKey<Structure> PUCCI_CHURCH =
        RegistryKey.of(RegistryKeys.STRUCTURE, new Identifier(JojoMod.MOD_ID, "pucci_church"));

    private ModStructures() {}
}
