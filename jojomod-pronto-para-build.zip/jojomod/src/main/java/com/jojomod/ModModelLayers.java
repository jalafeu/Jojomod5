package com.jojomod;

import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class ModModelLayers {
    public static final EntityModelLayer[] STAND = new EntityModelLayer[StandType.values().length];
    static {
        for (StandType t : StandType.values()) {
            STAND[t.ordinal()] = new EntityModelLayer(new Identifier(JojoMod.MOD_ID, "stand_" + t.id), "main");
        }
    }
}
