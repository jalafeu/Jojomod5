package com.jojomod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Guarda qual stand cada jogador possui (salvo no mundo). */
public class StandState extends PersistentState {
    private final Map<UUID, Integer> map = new HashMap<>();

    public static StandState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager()
            .getOrCreate(StandState::fromNbt, StandState::new, "jojomod_stands");
    }

    public static StandState fromNbt(NbtCompound nbt) {
        StandState s = new StandState();
        NbtCompound c = nbt.getCompound("stands");
        for (String k : c.getKeys()) s.map.put(UUID.fromString(k), c.getInt(k));
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound c = new NbtCompound();
        map.forEach((k, v) -> c.putInt(k.toString(), v));
        nbt.put("stands", c);
        return nbt;
    }

    public StandType get(UUID id) {
        Integer v = map.get(id);
        return v == null ? null : StandType.byOrdinal(v);
    }

    public void set(UUID id, StandType t) {
        if (t == null) map.remove(id); else map.put(id, t.ordinal());
        markDirty();
    }
}
