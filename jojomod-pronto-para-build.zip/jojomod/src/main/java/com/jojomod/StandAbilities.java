package com.jojomod;

import com.jojomod.entity.StandEntity;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BoneMealItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** As 5 habilidades de cada stand: slots 1-4 combate, slot 5 utilidade. */
public class StandAbilities {

    public static boolean use(StandEntity s, ServerPlayerEntity p, StandType t, int slot) {
        ServerWorld w = (ServerWorld) p.getWorld();
        return switch (t) {
            case STAR_PLATINUM -> starPlatinum(s, p, w, slot);
            case THE_WORLD -> theWorld(s, p, w, slot);
            case CRAZY_DIAMOND -> crazyDiamond(s, p, w, slot);
            case GOLD_EXPERIENCE -> goldExperience(s, p, w, slot);
        };
    }

    // ================= STAR PLATINUM =================
    private static boolean starPlatinum(StandEntity s, ServerPlayerEntity p, ServerWorld w, int slot) {
        switch (slot) {
            case 1 -> { // ORA rush
                s.startBarrage(40, 1.6f, 6f, 0);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 100, 1));
                return true;
            }
            case 2 -> { // Star Finger: ataque perfurante de longo alcance
                s.startPose(10);
                Vec3d start = p.getEyePos();
                Vec3d dir = p.getRotationVec(1f);
                for (double d = 1; d <= 14; d += 0.5) {
                    Vec3d pt = start.add(dir.multiply(d));
                    BlockPos bp = BlockPos.ofFloored(pt);
                    if (!w.getBlockState(bp).getCollisionShape(w, bp).isEmpty()) break;
                    w.spawnParticles(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
                    List<LivingEntity> hit = others(w, p, Box.of(pt, 1.2, 1.2, 1.2));
                    if (!hit.isEmpty()) {
                        hurt(w, p, hit.get(0), 12f);
                        break;
                    }
                }
                sound(w, p, SoundEvents.ENTITY_ARROW_SHOOT, 1.2f, 1.5f);
                return true;
            }
            case 3 -> { // Soco esmagador
                s.startPose(12);
                Vec3d l = p.getRotationVec(1f);
                for (LivingEntity e : others(w, p, front(p, 2.5, 4))) {
                    hurt(w, p, e, 14f);
                    e.takeKnockback(2.5, -l.x, -l.z);
                    e.setVelocity(e.getVelocity().add(0, 0.6, 0));
                    e.velocityModified = true;
                }
                Vec3d c = p.getEyePos().add(l.multiply(2.5));
                w.spawnParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 3, 0.5, 0.5, 0.5, 0);
                sound(w, p, SoundEvents.ENTITY_GENERIC_EXPLODE, 1f, 1.2f);
                return true;
            }
            case 4 -> { // Star Platinum: The World (parada curta)
                s.startPose(50);
                freeze(w, p, 20, 50);
                return true;
            }
            case 5 -> { // Visão aguçada: enxerga tudo ao redor
                s.startPose(20);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 300, 0));
                for (LivingEntity e : others(w, p, p.getBoundingBox().expand(24))) {
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 200, 0));
                }
                sound(w, p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1f, 1.6f);
                return true;
            }
        }
        return false;
    }

    // ================= THE WORLD =================
    private static boolean theWorld(StandEntity s, ServerPlayerEntity p, ServerWorld w, int slot) {
        switch (slot) {
            case 1 -> { // MUDA rush
                s.startBarrage(40, 1.8f, 6f, 0);
                return true;
            }
            case 2 -> { // Facas
                s.startPose(10);
                for (int i = 0; i < 5; i++) {
                    ArrowEntity a = new ArrowEntity(w, p);
                    a.setVelocity(p, p.getPitch(), p.getYaw() + (i - 2) * 6f, 0f, 3.0f, 0.5f);
                    a.setDamage(3.5);
                    a.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                    w.spawnEntity(a);
                }
                sound(w, p, SoundEvents.ITEM_TRIDENT_THROW, 1f, 1.5f);
                return true;
            }
            case 3 -> { // Rolo compressor: pancada em área
                s.startPose(15);
                Vec3d c = p.getPos().add(p.getRotationVec(1f).multiply(1, 0, 1).normalize().multiply(3));
                for (LivingEntity e : others(w, p, Box.of(c.add(0, 1, 0), 8, 4, 8))) {
                    hurt(w, p, e, 10f);
                    e.takeKnockback(1.3, c.x - e.getX(), c.z - e.getZ());
                }
                w.spawnParticles(ParticleTypes.EXPLOSION, c.x, c.y + 0.5, c.z, 6, 1.5, 0.3, 1.5, 0);
                sound(w, p, SoundEvents.BLOCK_ANVIL_LAND, 1.5f, 0.6f);
                return true;
            }
            case 4 -> { // ZA WARUDO
                s.startPose(100);
                freeze(w, p, 24, 100);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 100, 1));
                return true;
            }
            case 5 -> { // Salto temporal (teleporte curto)
                Vec3d dir = p.getRotationVec(1f);
                Vec3d best = null;
                for (double d = 1; d <= 12; d += 0.5) {
                    Box b = p.getBoundingBox().offset(dir.multiply(d));
                    if (!w.isSpaceEmpty(p, b)) break;
                    best = p.getPos().add(dir.multiply(d));
                }
                if (best == null) return false;
                p.requestTeleport(best.x, best.y, best.z);
                p.fallDistance = 0;
                sound(w, p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                return true;
            }
        }
        return false;
    }

    // ================= CRAZY DIAMOND =================
    private static boolean crazyDiamond(StandEntity s, ServerPlayerEntity p, ServerWorld w, int slot) {
        switch (slot) {
            case 1 -> { // DORA rush
                s.startBarrage(40, 1.4f, 5f, 0);
                return true;
            }
            case 2 -> { // Restaurar: cura e remove efeitos ruins
                s.startPose(15);
                for (PlayerEntity pl : w.getEntitiesByClass(PlayerEntity.class, p.getBoundingBox().expand(6), PlayerEntity::isAlive)) {
                    pl.heal(10f);
                    for (StatusEffectInstance inst : new ArrayList<>(pl.getStatusEffects())) {
                        if (inst.getEffectType().getCategory() == StatusEffectCategory.HARMFUL) {
                            pl.removeStatusEffect(inst.getEffectType());
                        }
                    }
                }
                sound(w, p, SoundEvents.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
                return true;
            }
            case 3 -> { // Retorno: puxa inimigos e causa dano
                s.startPose(12);
                for (LivingEntity e : others(w, p, front(p, 4, 8))) {
                    hurt(w, p, e, 4f);
                    e.takeKnockback(1.6, e.getX() - p.getX(), e.getZ() - p.getZ());
                }
                sound(w, p, SoundEvents.ENTITY_ENDER_EYE_LAUNCH, 1f, 1f);
                return true;
            }
            case 4 -> { // Reconstruir: conserta item na mão e armaduras
                s.startPose(20);
                ItemStack main = p.getMainHandStack();
                if (main.isDamageable()) main.setDamage(0);
                ItemStack off = p.getOffHandStack();
                if (off.isDamageable()) off.setDamage(0);
                for (ItemStack a : p.getArmorItems()) if (a.isDamageable()) a.setDamage(0);
                sound(w, p, SoundEvents.BLOCK_ANVIL_USE, 0.8f, 1.4f);
                return true;
            }
            case 5 -> { // Voltar no tempo: volta para onde estava ~5s atrás
                Vec3d old = s.rewindPos();
                if (old == null) return false;
                s.startPose(10);
                p.requestTeleport(old.x, old.y, old.z);
                p.fallDistance = 0;
                sound(w, p, SoundEvents.BLOCK_PORTAL_TRAVEL, 0.5f, 1.6f);
                return true;
            }
        }
        return false;
    }

    // ================= GOLD EXPERIENCE =================
    private static boolean goldExperience(StandEntity s, ServerPlayerEntity p, ServerWorld w, int slot) {
        switch (slot) {
            case 1 -> { // MUDA rush com energia de vida (enjoo)
                s.startBarrage(40, 1.2f, 5f, 1);
                return true;
            }
            case 2 -> { // Brotar vida: flores + regeneração em área
                s.startPose(15);
                flowers(w, p, 4, 30);
                for (PlayerEntity pl : w.getEntitiesByClass(PlayerEntity.class, p.getBoundingBox().expand(8), PlayerEntity::isAlive)) {
                    pl.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
                }
                sound(w, p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
                return true;
            }
            case 3 -> { // Sobrecarga de vida
                s.startPose(12);
                for (LivingEntity e : others(w, p, front(p, 3, 6))) {
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
                }
                sound(w, p, SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, 0.6f, 1.5f);
                return true;
            }
            case 4 -> { // Escudo de vida
                s.startPose(20);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 400, 2));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 1));
                sound(w, p, SoundEvents.ITEM_TOTEM_USE, 0.5f, 1.8f);
                return true;
            }
            case 5 -> { // Florescer: planta cresce, flores, e alimenta
                s.startPose(20);
                BlockPos o = p.getBlockPos();
                for (int dx = -5; dx <= 5; dx++) {
                    for (int dz = -5; dz <= 5; dz++) {
                        if (w.random.nextInt(3) != 0) continue;
                        BoneMealItem.useOnFertilizable(new ItemStack(Items.BONE_MEAL), w, o.add(dx, 0, dz));
                        BoneMealItem.useOnFertilizable(new ItemStack(Items.BONE_MEAL), w, o.add(dx, -1, dz));
                    }
                }
                flowers(w, p, 5, 20);
                p.getHungerManager().add(6, 0.6f);
                sound(w, p, SoundEvents.ITEM_BONE_MEAL_USE, 1f, 1f);
                return true;
            }
        }
        return false;
    }

    // ================= Utilitários =================
    private static List<LivingEntity> others(ServerWorld w, PlayerEntity p, Box box) {
        return w.getEntitiesByClass(LivingEntity.class, box, e -> e != p && e.isAlive() && !(e instanceof StandEntity));
    }

    private static Box front(PlayerEntity p, double reach, double size) {
        return Box.of(p.getEyePos().add(p.getRotationVec(1f).multiply(reach)), size, size, size);
    }

    private static void hurt(ServerWorld w, PlayerEntity p, LivingEntity e, float dmg) {
        e.timeUntilRegen = 0;
        e.damage(w.getDamageSources().playerAttack(p), dmg);
    }

    private static void sound(ServerWorld w, PlayerEntity p, SoundEvent ev, float vol, float pitch) {
        w.playSound(null, p.getBlockPos(), ev, SoundCategory.PLAYERS, vol, pitch);
    }

    /** "Para o tempo": paralisa tudo em volta (efeitos), exceto o usuário. */
    private static void freeze(ServerWorld w, PlayerEntity p, double radius, int ticks) {
        for (LivingEntity e : others(w, p, p.getBoundingBox().expand(radius))) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, 10, false, false));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, ticks, 128, false, false));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, ticks, 10, false, false));
        }
        sound(w, p, SoundEvents.BLOCK_BEACON_DEACTIVATE, 2f, 0.5f);
    }

    private static void flowers(ServerWorld w, PlayerEntity p, int radius, int tries) {
        Block[] f = {Blocks.POPPY, Blocks.DANDELION, Blocks.AZURE_BLUET, Blocks.OXEYE_DAISY};
        BlockPos o = p.getBlockPos();
        int span = radius * 2 + 1;
        for (int i = 0; i < tries; i++) {
            BlockPos pos = o.add(w.random.nextInt(span) - radius, 0, w.random.nextInt(span) - radius);
            if (w.isAir(pos) && w.getBlockState(pos.down()).isOf(Blocks.GRASS_BLOCK)) {
                w.setBlockState(pos, f[w.random.nextInt(f.length)].getDefaultState());
            }
        }
    }
}
