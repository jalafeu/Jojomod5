package com.jojomod;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Arrays;

/** /stand set <nome> e /stand clear (permissão de operador, útil para testar). */
public class ModCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("stand")
                .requires(src -> src.hasPermissionLevel(2))
                .then(CommandManager.literal("set")
                    .then(CommandManager.argument("nome", StringArgumentType.word())
                        .suggests((ctx, b) -> CommandSource.suggestMatching(
                            Arrays.stream(StandType.values()).map(t -> t.id), b))
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            StandType t = StandType.byId(StringArgumentType.getString(ctx, "nome"));
                            if (t == null) {
                                ctx.getSource().sendError(Text.literal("Stand desconhecido."));
                                return 0;
                            }
                            StandManager.setStand(p, t);
                            return 1;
                        })))
                .then(CommandManager.literal("clear").executes(ctx -> {
                    StandManager.setStand(ctx.getSource().getPlayerOrThrow(), null);
                    return 1;
                }))));
    }
}
