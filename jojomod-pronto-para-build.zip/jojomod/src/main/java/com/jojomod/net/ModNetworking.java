package com.jojomod.net;

import com.jojomod.JojoMod;
import com.jojomod.StandManager;
import com.jojomod.StandType;
import com.jojomod.entity.StandEntity;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class ModNetworking {
    /** Cliente -> servidor: byte kind, byte a, byte b. kind 0 = tecla (a = 0 invocar, 1..5 habilidade); kind 1 = mouse (a = esquerdo, b = direito). */
    public static final Identifier INPUT = new Identifier(JojoMod.MOD_ID, "input");
    /** Servidor -> cliente: int com o stand do jogador (-1 = nenhum). */
    public static final Identifier SYNC = new Identifier(JojoMod.MOD_ID, "sync");
    /** Servidor -> cliente: int slot, int ticks de recarga. */
    public static final Identifier COOLDOWN = new Identifier(JojoMod.MOD_ID, "cooldown");

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(INPUT, (server, player, handler, buf, sender) -> {
            int kind = buf.readByte();
            int a = buf.readByte();
            int b = buf.readByte();
            server.execute(() -> {
                if (kind == 0) {
                    if (a == 0) StandManager.toggleSummon(player);
                    else StandManager.useAbility(player, a);
                } else {
                    StandEntity s = StandEntity.findFor(player);
                    if (s != null) {
                        s.attackHeld = a != 0;
                        s.guardHeld = b != 0;
                    }
                }
            });
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendSync(handler.player));
    }

    public static void sendSync(ServerPlayerEntity p) {
        StandType t = StandManager.getStand(p);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(t == null ? -1 : t.ordinal());
        ServerPlayNetworking.send(p, SYNC, buf);
    }

    public static void sendCooldown(ServerPlayerEntity p, int slot, int ticks) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(slot);
        buf.writeInt(ticks);
        ServerPlayNetworking.send(p, COOLDOWN, buf);
    }
}
