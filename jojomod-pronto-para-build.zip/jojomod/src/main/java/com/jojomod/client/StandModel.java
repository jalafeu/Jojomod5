package com.jojomod.client;

import com.jojomod.StandType;
import com.jojomod.entity.StandEntity;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modelo 3D dos stands: corpo humanoide + peças extras (cabelo, ombreiras, placas, chifres...)
 * diferentes para cada stand. Textura 64x64: metade de cima = corpo, metade de baixo = peças extras
 * (região 1 = linha y32-47 inteira, região 2 = y48-63 x0-31, região 3 = y48-63 x32-63).
 */
public class StandModel extends BipedEntityModel<StandEntity> {

    public StandModel(ModelPart root) {
        super(root);
    }

    public static TexturedModelData create(StandType type) {
        ModelData data = BipedEntityModel.getModelData(Dilation.NONE, 0f);
        ModelPartData root = data.getRoot();
        ModelPartData head = root.getChild("head");
        ModelPartData body = root.getChild("body");
        ModelPartData rArm = root.getChild("right_arm");
        ModelPartData lArm = root.getChild("left_arm");
        ModelPartData rLeg = root.getChild("right_leg");
        ModelPartData lLeg = root.getChild("left_leg");

        // Peças comuns: ombreiras, cinto, botas, braceletes
        add(rArm, "pad_r", 2, -3.6f, -2.6f, -2.6f, 5.2f, 3f, 5.2f);
        add(lArm, "pad_l", 2, -1.6f, -2.6f, -2.6f, 5.2f, 3f, 5.2f);
        add(body, "belt", 3, -4.5f, 9.5f, -2.5f, 9f, 2f, 5f);
        add(rLeg, "boot_r", 2, -2.5f, 8.5f, -2.5f, 5f, 3.5f, 5f);
        add(lLeg, "boot_l", 2, -2.5f, 8.5f, -2.5f, 5f, 3.5f, 5f);
        add(rArm, "brace_r", 3, -3.5f, 7f, -2.5f, 5f, 3f, 5f);
        add(lArm, "brace_l", 3, -1.5f, 7f, -2.5f, 5f, 3f, 5f);

        switch (type) {
            case STAR_PLATINUM -> {
                add(head, "hair_top", 1, -4.5f, -9f, -4.5f, 9f, 1.5f, 9f);
                add(head, "hair_back", 1, -4.5f, -8f, 3.6f, 9f, 8f, 2f);
                add(head, "fringe", 1, -4.5f, -9f, -5.2f, 9f, 2f, 1.2f);
                add(body, "chest", 2, -4.6f, 0.3f, -2.6f, 9.2f, 5f, 1f);
            }
            case THE_WORLD -> {
                add(head, "headband", 1, -4.5f, -6.5f, -4.5f, 9f, 1.5f, 9f);
                add(head, "hair_top", 2, -4f, -9f, -4f, 8f, 1.5f, 8f);
                add(head, "hair_spike", 2, -3f, -11.5f, -1f, 6f, 3f, 2f);
                add(body, "strap_l", 1, -4.5f, 0f, -2.7f, 2f, 12f, 1f);
                add(body, "strap_r", 1, 2.5f, 0f, -2.7f, 2f, 12f, 1f);
            }
            case CRAZY_DIAMOND -> {
                add(head, "hair_top", 1, -4.5f, -9f, -4.5f, 9f, 2f, 9f);
                add(head, "pompadour", 1, -4f, -11.5f, -6.5f, 8f, 4f, 7f);
                add(body, "heart_l", 2, -4.2f, 1f, -2.7f, 4f, 4f, 1f);
                add(body, "heart_r", 2, 0.2f, 1f, -2.7f, 4f, 4f, 1f);
            }
            case GOLD_EXPERIENCE -> {
                add(head, "crest", 1, -1f, -11.5f, -4.5f, 2f, 3.5f, 9f);
                add(head, "horn_l", 2, 4.5f, -5f, -1f, 2f, 3f, 2f);
                add(head, "horn_r", 2, -6.5f, -5f, -1f, 2f, 3f, 2f);
                add(body, "emblem", 2, -2f, 2f, -2.6f, 4f, 4f, 1f);
            }
        }
        return TexturedModelData.of(data, 64, 64);
    }

    /** Adiciona uma peça extra usando uma das 3 regiões de cor da textura. */
    private static void add(ModelPartData parent, String name, int region,
                            float x, float y, float z, float w, float h, float d) {
        int u = region == 3 ? 32 : 0;
        int v = region == 1 ? 32 : 48;
        parent.addChild(name, ModelPartBuilder.create().uv(u, v).cuboid(x, y, z, w, h, d), ModelTransform.NONE);
    }

    @Override
    public void setAngles(StandEntity e, float limb, float limbDist, float anim, float headYaw, float headPitch) {
        super.setAngles(e, limb, limbDist, anim, headYaw, headPitch);
        switch (e.getAction()) {
            case StandEntity.ACT_BARRAGE -> punchPose(anim * 2.4f);
            case StandEntity.ACT_PUNCH -> punchPose(anim * 1.3f);
            case StandEntity.ACT_GUARD -> {
                rightArm.pitch = -1.3f; leftArm.pitch = -1.3f;
                rightArm.yaw = 0.8f;    leftArm.yaw = -0.8f;
                rightArm.roll = 0f;     leftArm.roll = 0f;
            }
            case StandEntity.ACT_POSE -> {
                rightArm.pitch = -2.7f; leftArm.pitch = -2.7f;
                rightArm.yaw = 0f;      leftArm.yaw = 0f;
                rightArm.roll = 0.35f;  leftArm.roll = -0.35f;
            }
            default -> {
                // parado: braços levemente balançando
                rightArm.roll += MathHelper.sin(anim * 0.1f) * 0.05f + 0.05f;
                leftArm.roll -= MathHelper.sin(anim * 0.1f) * 0.05f + 0.05f;
            }
        }
    }

    private void punchPose(float t) {
        rightArm.pitch = -1.5f + MathHelper.sin(t) * 0.8f;
        leftArm.pitch = -1.5f + MathHelper.sin(t + MathHelper.PI) * 0.8f;
        rightArm.yaw = 0f; leftArm.yaw = 0f;
        rightArm.roll = 0f; leftArm.roll = 0f;
    }
}
