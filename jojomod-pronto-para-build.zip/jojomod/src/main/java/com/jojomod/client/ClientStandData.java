package com.jojomod.client;

import com.jojomod.StandType;

public class ClientStandData {
    public static StandType type = null;
    /** Tick do mundo em que cada slot (1..5) fica pronto. */
    public static final long[] cooldownEnd = new long[6];
}
