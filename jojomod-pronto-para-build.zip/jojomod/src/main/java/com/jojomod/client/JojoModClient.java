package com.jojomod.client;

import com.jojomod.ModEntities;
import com.jojomod.ModModelLayers;
import com.jojomod.StandType;
import com.jojomod.entity.StandEntity;
import com.jojomod.net.ModNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class JojoModClient implements ClientModInitializer {
    private static final String CATEGORY = "category.jojomod";
    private static KeyBinding SUMMON;
    private static final KeyBinding[] ABILITY = new KeyBinding[5];
    private static final int[] DEFAULT_KEYS = {GLFW.GLFW_KEY_R, GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_X};

    private static boolean lastAttack = false, lastGuard = false;

    @Override
    public void onInitializeClient() {
        // Renderer e modelos 3D
        for (StandType t : StandType.values()) {
            EntityModelLayerRegistry.registerModelLayer(ModModelLayers.STAND[t.ordinal()], () -> StandModel.create(t));
        }
        EntityRendererRegistry.register(ModEntities.STAND, StandEntityRenderer::new);

        // Teclas (podem ser trocadas em Controles > JoJo Mod)
        SUMMON = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.jojomod.summon", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, CATEGORY));
        for (int i = 0; i < 5; i++) {
            ABILITY[i] = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.jojomod.ability" + (i + 1), InputUtil.Type.KEYSYM, DEFAULT_KEYS[i], CATEGORY));
        }

        // Pacotes do servidor
        ClientPlayNetworking.registerGlobalReceiver(ModNetworking.SYNC, (client, handler, buf, sender) -> {
            int v = buf.readInt();
            client.execute(() -> ClientStandData.type = v < 0 ? null : StandType.byOrdinal(v));
        });
        ClientPlayNetworking.registerGlobalReceiver(ModNetworking.COOLDOWN, (client, handler, buf, sender) -> {
            int slot = buf.readInt();
            int ticks = buf.readInt();
            client.execute(() -> {
                if (client.world != null && slot >= 1 && slot <= 5) {
                    ClientStandData.cooldownEnd[slot] = client.world.getTime() + ticks;
                }
            });
        });

        // Entrada: teclas, botão esquerdo (socar) e direito (bloquear)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (SUMMON.wasPressed()) sendInput(0, 0, 0);
            for (int i = 0; i < 5; i++) {
                while (ABILITY[i].wasPressed()) sendInput(0, i + 1, 0);
            }
            boolean atk = false, grd = false;
            if (client.currentScreen == null && ClientStandData.type != null
                    && StandEntity.findFor(client.player) != null) {
                atk = client.options.attackKey.isPressed();
                grd = client.options.useKey.isPressed()
                    && client.player.getMainHandStack().isEmpty()
                    && client.player.getOffHandStack().isEmpty();
            }
            if (atk != lastAttack || grd != lastGuard) {
                sendInput(1, atk ? 1 : 0, grd ? 1 : 0);
                lastAttack = atk;
                lastGuard = grd;
            }
        });

        // HUD com as habilidades
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            StandType t = ClientStandData.type;
            if (t == null || mc.player == null || mc.world == null || mc.options.hudHidden) return;
            TextRenderer tr = mc.textRenderer;
            int x = 6, y = 6;
            ctx.drawTextWithShadow(tr, Text.translatable("stand.jojomod." + t.id).formatted(Formatting.GOLD, Formatting.BOLD), x, y, 0xFFFFFF);
            ctx.drawTextWithShadow(tr, Text.literal("[").append(SUMMON.getBoundKeyLocalizedText()).append("] ")
                .append(Text.translatable("hud.jojomod.summon")).formatted(Formatting.AQUA), x, y + 12, 0xFFFFFF);
            for (int i = 0; i < 5; i++) {
                long left = ClientStandData.cooldownEnd[i + 1] - mc.world.getTime();
                MutableText line = Text.literal("[").append(ABILITY[i].getBoundKeyLocalizedText()).append("] ")
                    .append(Text.translatable("ability.jojomod." + t.id + "." + (i + 1)));
                if (left > 0) line.append(" (" + ((left + 19) / 20) + "s)");
                line.formatted(left > 0 ? Formatting.GRAY : (i == 4 ? Formatting.GREEN : Formatting.WHITE));
                ctx.drawTextWithShadow(tr, line, x, y + 24 + i * 12, 0xFFFFFF);
            }
        });
    }

    private static void sendInput(int kind, int a, int b) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeByte(kind);
        buf.writeByte(a);
        buf.writeByte(b);
        ClientPlayNetworking.send(ModNetworking.INPUT, buf);
    }
}
