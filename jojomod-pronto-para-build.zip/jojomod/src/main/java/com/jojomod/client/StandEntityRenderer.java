package com.jojomod.client;

import com.jojomod.JojoMod;
import com.jojomod.ModModelLayers;
import com.jojomod.StandType;
import com.jojomod.entity.StandEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class StandEntityRenderer extends BipedEntityRenderer<StandEntity, StandModel> {
    private final StandModel[] models = new StandModel[StandType.values().length];

    public StandEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new StandModel(ctx.getPart(ModModelLayers.STAND[0])), 0f);
        for (StandType t : StandType.values()) {
            models[t.ordinal()] = new StandModel(ctx.getPart(ModModelLayers.STAND[t.ordinal()]));
        }
    }

    @Override
    public void render(StandEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        this.model = models[entity.getStandType().ordinal()];
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    @Override
    public Identifier getTexture(StandEntity entity) {
        return new Identifier(JojoMod.MOD_ID, "textures/entity/stand_" + entity.getStandType().id + ".png");
    }
}
