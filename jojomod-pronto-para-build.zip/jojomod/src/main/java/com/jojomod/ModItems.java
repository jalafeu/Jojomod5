package com.jojomod;

import com.jojomod.item.StandArrowItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item STAND_ARROW = Registry.register(Registries.ITEM,
        new Identifier(JojoMod.MOD_ID, "stand_arrow"), new StandArrowItem(new Item.Settings().maxCount(16)));

    public static void register() {
        Registry.register(Registries.ITEM_GROUP, new Identifier(JojoMod.MOD_ID, "jojo"),
            FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.jojomod.jojo"))
                .icon(() -> new ItemStack(STAND_ARROW))
                .entries((ctx, entries) -> entries.add(STAND_ARROW))
                .build());
    }
}
