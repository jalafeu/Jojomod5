package com.jojomod.entity;

import com.jojomod.StandType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Stand do jogador: flutua ao lado, soca (botão esquerdo), bloqueia (botão direito) e usa habilidades. */
public class StandEntity extends MobEntity {
    public static final int ACT_IDLE = 0, ACT_PUNCH = 1, ACT_BARRAGE = 2, ACT_GUARD = 3, ACT_POSE = 4;

    private static final TrackedData<Integer> TYPE =
        DataTracker.registerData(StandEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ACTION =
        DataTracker.registerData(StandEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Optional<UUID>> OWNER =
        DataTracker.registerData(StandEntity.class, TrackedDataHandlerRegistry.OPTIONAL_UUID);

    // Entradas do jogador (preenchidas pelo servidor)
    public boolean attackHeld = false;
    public boolean guardHeld = false;

    private int barrageTicks = 0;
    private float barrageDamage = 0, barrageFinal = 0;
    private int barrageEffect = 0;
    private int poseTicks = 0;
    private final ArrayDeque<Vec3d> history = new ArrayDeque<>();

    public StandEntity(EntityType<? extends StandEntity> type, World world) {
        super(type, world);
        this.noClip = true;
        this.setNoGravity(true);
        this.setPersistent();
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(TYPE, 0);
        this.dataTracker.startTracking(ACTION, 0);
        this.dataTracker.startTracking(OWNER, Optional.empty());
    }

    public StandType getStandType() { return StandType.byOrdinal(this.dataTracker.get(TYPE)); }
    public void setStandType(StandType t) { this.dataTracker.set(TYPE, t.ordinal()); }
    public int getAction() { return this.dataTracker.get(ACTION); }
    public void setOwner(PlayerEntity p) { this.dataTracker.set(OWNER, Optional.of(p.getUuid())); }
    public UUID getOwnerUuid() { return this.dataTracker.get(OWNER).orElse(null); }

    /** Procura o stand ativo de um jogador (funciona no cliente e no servidor). */
    public static StandEntity findFor(PlayerEntity owner) {
        List<StandEntity> list = owner.getWorld().getEntitiesByClass(
            StandEntity.class, owner.getBoundingBox().expand(64),
            s -> owner.getUuid().equals(s.getOwnerUuid()));
        return list.isEmpty() ? null : list.get(0);
    }

    // ---------- API usada pelas habilidades ----------
    public void startBarrage(int ticks, float dmg, float finalDmg, int effect) {
        barrageTicks = ticks;
        barrageDamage = dmg;
        barrageFinal = finalDmg;
        barrageEffect = effect;
    }

    public void startPose(int ticks) { poseTicks = Math.max(poseTicks, ticks); }

    /** Posição do dono há ~5 segundos (para "voltar no tempo"). */
    public Vec3d rewindPos() { return history.peekFirst(); }

    // ---------- Tick ----------
    @Override
    public void tick() {
        super.tick();
        World w = getWorld();
        if (w.isClient) return;

        UUID id = getOwnerUuid();
        PlayerEntity owner = id == null ? null : w.getPlayerByUuid(id);
        if (owner == null || !owner.isAlive() || owner.getWorld() != w) {
            this.discard();
            return;
        }

        if (this.age % 5 == 0) {
            history.addLast(owner.getPos());
            if (history.size() > 20) history.removeFirst();
        }

        // Define a ação atual (prioridade: rajada > bloqueio > pose > soco)
        int action = ACT_IDLE;
        if (barrageTicks > 0) action = ACT_BARRAGE;
        else if (guardHeld) action = ACT_GUARD;
        else if (poseTicks > 0) action = ACT_POSE;
        else if (attackHeld) action = ACT_PUNCH;
        if (poseTicks > 0) poseTicks--;
        if (getAction() != action) this.dataTracker.set(ACTION, action);

        // Posição
        float yaw = owner.getYaw();
        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        double rx = -Math.cos(rad), rz = -Math.sin(rad);
        double tx, ty, tz;
        if (action == ACT_IDLE) {
            double bob = Math.sin(this.age * 0.15) * 0.08;
            tx = owner.getX() - fx * 0.9 + rx * 0.9;
            ty = owner.getY() + 0.25 + bob;
            tz = owner.getZ() - fz * 0.9 + rz * 0.9;
        } else {
            double dist = action == ACT_GUARD ? 1.0 : 1.3;
            tx = owner.getX() + fx * dist;
            ty = owner.getY();
            tz = owner.getZ() + fz * dist;
        }
        this.refreshPositionAndAngles(
            getX() + (tx - getX()) * 0.5,
            getY() + (ty - getY()) * 0.5,
            getZ() + (tz - getZ()) * 0.5,
            yaw, 0f);
        this.setHeadYaw(yaw);
        this.setBodyYaw(yaw);

        // Efeitos da ação
        switch (action) {
            case ACT_BARRAGE -> {
                barrageTicks--;
                if (barrageTicks % 2 == 0) {
                    boolean last = barrageTicks <= 0;
                    strike(owner, last ? barrageFinal : barrageDamage, last ? 1.8 : 0.25, barrageEffect);
                }
            }
            case ACT_PUNCH -> {
                if (this.age % 6 == 0) strike(owner, getStandType().punchDamage, 0.5, 0);
            }
            case ACT_GUARD -> {
                // Bloqueio: o dono recebe 80% menos dano enquanto segura o botão direito
                owner.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 5, 3, false, false, false));
            }
            default -> { }
        }
    }

    /** Um soco do stand na direção em que o dono está olhando. */
    private void strike(PlayerEntity owner, float dmg, double knockback, int effectKind) {
        World w = getWorld();
        Vec3d look = owner.getRotationVec(1f);
        Vec3d center = owner.getEyePos().add(look.multiply(2.3));
        Box box = Box.of(center, 2.6, 2.6, 2.6);
        boolean any = false;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                x -> x != owner && x != this && !(x instanceof StandEntity) && x.isAlive())) {
            e.timeUntilRegen = 0;
            e.damage(w.getDamageSources().playerAttack(owner), dmg);
            e.takeKnockback(knockback, -look.x, -look.z);
            if (effectKind == 1) e.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 80, 0));
            any = true;
        }
        this.swingHand(this.age % 4 < 2 ? Hand.MAIN_HAND : Hand.OFF_HAND);
        w.playSound(null, getBlockPos(),
            any ? SoundEvents.ENTITY_PLAYER_ATTACK_STRONG : SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
            SoundCategory.PLAYERS, 0.8f, 0.9f + this.random.nextFloat() * 0.3f);
    }

    // ---------- Stand é intocável ----------
    @Override public boolean damage(DamageSource source, float amount) { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return true; }
    @Override public boolean isAttackable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override protected void pushAway(Entity entity) { }
    @Override public boolean canHaveStatusEffect(StatusEffectInstance effect) { return false; }
}
