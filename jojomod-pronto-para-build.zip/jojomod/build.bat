@echo off
REM Requer JDK 17 e Gradle 8.5+ no PATH. Gera build\libs\jojomod-0.4.0.jar
call gradle build
echo.
echo JAR pronto em: build\libs\jojomod-0.4.0.jar  (NAO use o -sources.jar)
pause
